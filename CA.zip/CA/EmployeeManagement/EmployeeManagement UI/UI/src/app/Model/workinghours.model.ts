export interface WorkingManagement{
    id: 0;
    designation: string;
    from: string;
    to: string;
    totalTime:string;
}