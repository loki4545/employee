export interface Employee{
    id: number;
    empId:string;
    empName: string;
    phone: string;
    email: string;
    address: string;
    designation: string;
    salaryGrade:string;
}