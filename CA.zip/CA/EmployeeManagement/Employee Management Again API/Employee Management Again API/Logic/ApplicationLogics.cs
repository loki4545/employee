﻿using Employee_Management_Again_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee_Management_Again_API.Logic
{
    public class ApplicationLogics
    {

        public void SaveDesignation(Designation aDesignation)
        {

        }

        public void OpenDesignation(long DesignationId)
        {

        }

        public void DeleteDesignation(long DesignationId)
        {

        }

        /// <summary>
        /// ////////////////////////////
        /// </summary>
        public void SaveEmploee(Employee aEmployee)
        {

        }

        public void OpenEmployee(long EmployeeID)
        {

        }

        public void DeleteEmployee(long EmployeeId)
        {

        }


        /// <summary>
        /// ////////////////////////////
        /// </summary>
        public void SaveRequestLeave(RequestLeave aRequestLeave)
        {

        }

        public void OpenRequestLeave(long RequestLeaveId)
        {

        }
        /// <summary>
        /// ////////////////////////////
        /// </summary>
        public void SaveTaskDetial(WorkingHours aWorkingHours)
        {

        }
    }
}
