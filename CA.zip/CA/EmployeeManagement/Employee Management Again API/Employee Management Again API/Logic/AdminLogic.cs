﻿using Employee_Management_Again_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee_Management_Again_API.Logic
{
    public class AdminLogic
    {

        public void saveUser(User aUser)
        { 
        
        }

        public void LoginUser(string UserName, string Pwd)
        {

        }
    }
}
