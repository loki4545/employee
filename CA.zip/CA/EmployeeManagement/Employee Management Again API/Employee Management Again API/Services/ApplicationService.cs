﻿using Employee_Management_Again_API.Logic;
using Employee_Management_Again_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee_Management_Again_API.Services
{
    public class ApplicationService
    {



        //////////////////Desgination
        public void SaveDesignation(Designation designation)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.SaveDesignation(designation);
        }

        public void OpenDesignation(long designationId)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.OpenDesignation(designationId);
        }

        public void DeleteDesignation(long designationId)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.DeleteDesignation(designationId);
        }



        //////////////////Employee
        public void SaveEmployee(Employee aEmployee)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.SaveEmploee(aEmployee);
        }

        public void OpenEmployee(long EmployeeId)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.OpenEmployee(EmployeeId);
        }

        public void DeleteEmployee(long EmployeeId)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.DeleteEmployee(EmployeeId);
        }



        //////////////////RequestLeave
        public void SaveRequestLeave(RequestLeave aRequestLeave)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.SaveRequestLeave(aRequestLeave);
        }

        public void OpenRequestLeave(long aRequestLeaveId)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.OpenRequestLeave(aRequestLeaveId);
        }


        //////////////////RequestLeave
        public void SaveWorkingTask(WorkingHours aWorkingHours)
        {
            ApplicationLogics lbussinessLogics = new ApplicationLogics();
            lbussinessLogics.SaveTaskDetial(aWorkingHours);
        }


    }
}
