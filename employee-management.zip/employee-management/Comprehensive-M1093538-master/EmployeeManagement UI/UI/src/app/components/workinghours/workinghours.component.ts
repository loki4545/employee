import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workinghours',
  templateUrl: './workinghours.component.html',
  styleUrls: ['./workinghours.component.css']
})
export class WorkinghoursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
