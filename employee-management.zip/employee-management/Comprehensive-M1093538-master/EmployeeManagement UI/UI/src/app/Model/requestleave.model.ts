export interface Leave{
    id: 0;
    empName: string;
    from: any;
    to: any;
    cause:string;
}