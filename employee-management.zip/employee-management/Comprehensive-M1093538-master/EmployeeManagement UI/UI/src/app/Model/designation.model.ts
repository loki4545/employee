export interface Designation{
    id: number;
    designationName:string;
    roleName: string;
    department:string;
}