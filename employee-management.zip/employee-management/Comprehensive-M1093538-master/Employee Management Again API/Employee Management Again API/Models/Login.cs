﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee_Management_Again_API.Models
{
    public class Login
    {
        public String Email { get; set; }
        public String Pwd { get; set; }
    }
}
